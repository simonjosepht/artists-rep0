package bank;

import java.util.HashMap;
import java.util.Map;

public class Bank {

    private final Map<Integer, Account> accounts = new HashMap<>();
    private int nextAccountNumber = 1;

    public String createAccount() {
        int number = nextAccountNumber++;
        accounts.put(number, new Account(number));
        return "New account created with account number " + number;
    }

    public String deposit(int accountNumber, int amount) {
        Account account = accounts.get(accountNumber);
        if (account == null) return "Account number " + accountNumber + " not found";
        account.deposit(amount);
        return amount + " deposited to account number " + accountNumber;
    }

    public String withdraw(int accountNumber, int amount) {
        Account account = accounts.get(accountNumber);
        if (account == null) return "Account number " + accountNumber + " not found";
        return account.withdraw(amount)
                ? amount + " withdrawn from account number " + accountNumber
                : "Withdrawal limit exceeded";
    }

    public String displayBalance(int accountNumber) {
        Account account = accounts.get(accountNumber);
        if (account == null) return "Account number " + accountNumber + " not found";
        return "Balance for account number " + accountNumber + ": " + account.getBalance();
    }

    public String displayBankBalance() {
        int total = accounts.values().stream().mapToInt(Account::getBalance).sum();
        return "Total bank balance: " + total;
    }
}
