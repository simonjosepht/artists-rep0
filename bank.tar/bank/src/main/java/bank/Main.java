package bank;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.err.println("Usage: java -jar digital-bank.jar <input-file>");
            System.exit(1);
        }

        Bank bank = new Bank();
        List<String> lines = Files.readAllLines(Paths.get(args[0]));

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;

            String[] parts = trimmed.split("\\s+");
            System.out.println(execute(bank, parts));

        }
    }

    static String execute(Bank bank, String[] parts) {
        return switch (parts[0]) {
            case "create_account" -> bank.createAccount();
            case "deposit" -> bank.deposit(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            case "withdraw" -> bank.withdraw(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            case "display_balance" -> bank.displayBalance(Integer.parseInt(parts[1]));
            case "display_bank_balance" -> bank.displayBankBalance();
            default -> "Unknown command: " + parts[0];
        };
    }

}
