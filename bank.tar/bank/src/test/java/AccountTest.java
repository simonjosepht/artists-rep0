import bank.Account;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class AccountTest {

    @Test
    void TestNewAccount() {
        assertEquals(0, new Account(1).getBalance());
    }

    @Test
    void TestDeposit() {
        Account account = new Account(1);
        account.deposit(500);
        assertEquals(500, account.getBalance());
    }

    @Test
    void TestWithdrawSuccess() {
        Account account = new Account(1);
        account.deposit(1000);
        assertTrue(account.withdraw(400));
        assertEquals(600, account.getBalance());
    }

    @Test
    void TestInvalidWithdrawFalse() {
        Account account = new Account(1);
        account.deposit(100);
        assertFalse(account.withdraw(200));
        assertEquals(100, account.getBalance());
    }

}

