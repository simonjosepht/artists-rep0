import bank.Bank;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BankTest {

    private Bank bank;

    @BeforeEach
    void setUp() {
        bank = new Bank();
    }

    @Test
    void TestCreateAccount() {
        assertEquals("New account created with account number 1", bank.createAccount());
        assertEquals("New account created with account number 2", bank.createAccount());
    }

    @Test
    void TestDepositAccount() {
        bank.createAccount();
        assertEquals("1000 deposited to account number 1", bank.deposit(1, 1000));
    }

    @Test
    void TestDepositInvalidAccount() {
        assertEquals("Account number 5 not found", bank.deposit(5, 100));
    }

    @Test
    void TestWithdrawAccount() {
        bank.createAccount();
        bank.deposit(1, 1000);
        assertEquals("500 withdrawn from account number 1", bank.withdraw(1, 500));
    }

    @Test
    void TestWithdrawExceedingBalance() {
        bank.createAccount();
        bank.deposit(1, 500);
        assertEquals("Withdrawal limit exceeded", bank.withdraw(1, 1000));
    }

    @Test
    void TestWithdrawInvalidAccount() {
        assertEquals("Account number 5 not found", bank.withdraw(5, 100));
    }

    @Test
    void TestDisplayBalance() {
        bank.createAccount();
        bank.deposit(1, 750);
        assertEquals("Balance for account number 1: 750", bank.displayBalance(1));
    }

    @Test
    void TestDisplayBalanceInvalidAccount() {
        assertEquals("Account number 3 not found", bank.displayBalance(3));
    }

    @Test
    void TestDisplayBankBalance() {
        bank.createAccount();
        bank.createAccount();
        bank.deposit(1, 500);
        bank.deposit(2, 1000);
        assertEquals("Total bank balance: 1500", bank.displayBankBalance());
    }

    @Test
    void TestFullSampleScenario() {
        assertEquals("New account created with account number 1", bank.createAccount());
        assertEquals("1000 deposited to account number 1",        bank.deposit(1, 1000));
        assertEquals("500 withdrawn from account number 1",       bank.withdraw(1, 500));
        assertEquals("Balance for account number 1: 500",         bank.displayBalance(1));
        assertEquals("New account created with account number 2", bank.createAccount());
        assertEquals("Withdrawal limit exceeded",                 bank.withdraw(1, 1000));
        assertEquals("1000 deposited to account number 2",        bank.deposit(2, 1000));
        assertEquals("Account number 5 not found",                bank.withdraw(5, 1000));
        assertEquals("Total bank balance: 1500",                  bank.displayBankBalance());
    }
}
