# Digital Bank

A simple in-memory digital bank implemented in Java.

## Requirements

- Java 11+
- Maven 3.6+



## Run

```bash
java -jar target/digital-bank-1.0.jar input.txt
```



## Design

```
src/main/java/bank/
├── Account.java   — holds account number and balance; deposit/withdraw logic
├── Bank.java      — owns the account registry; exposes all banking operations
└── Main.java      — reads the input file, dispatches each command to Bank

src/test/java/bank/
├── AccountTest.java  — unit tests for Account
└── BankTest.java     — unit tests for Bank (includes full sample scenario)
```

## Supported Commands

| Command | Description |
|---|---|
| `create_account` | Opens a new account; prints the assigned account number |
| `deposit {account} {amount}` | Deposits amount into the account |
| `withdraw {account} {amount}` | Withdraws amount; rejected if insufficient funds |
| `display_balance {account}` | Prints the current balance |
| `display_bank_balance` | Prints the sum of all account balances |
